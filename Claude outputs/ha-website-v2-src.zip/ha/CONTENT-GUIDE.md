# Hanif Abdullah — website content guide

All words, news items, timeline chapters, results and contact addresses live in
**`src/content/site.js`**. Edit that one file to update the site — no layout code needs to change.

| Section | Where to edit |
|---|---|
| Name, tagline, "Hope Always", emails, social links | `BRAND` |
| Menu order / labels | `NAV` |
| Home intro + latest news cards | `HOME` |
| About: story, goals, vision | `ABOUT` |
| Journey timeline (started tennis → first tournament → Spain → Thailand → future) | `JOURNEY.milestones` (set `status: 'next'` on the upcoming one) |
| Gallery photos & videos | `GALLERY` (put image files in `public/`, YouTube embed URLs in `embed`) |
| Results table, titles, rankings note | `RESULTS` |
| Partners: sponsors, equipment, academies | `PARTNERS` |
| Contact channels | `CONTACT.channels` |

## Brand rules baked into the design
- Colours: Deep Burgundy `#6E0F1F` + White (primary); Charcoal `#1B1B1E` + Silver `#C9CBD1` (secondary). Tokens are at the top of `src/styles.css`.
- Photography: black / white / burgundy, minimal editing, clean backgrounds. Photos in the gallery get a light grayscale/contrast treatment automatically so they feel consistent.
- Voice: professional, respectful, humble, hard-working — record losses as honestly as wins.

## Pages
Routing is hash-based (`#/about`, `#/journey/spain`, `#/contact/media`) so it works on any static host with no server configuration.

## Running
```
npm install
npm run dev      # local preview
npm run build    # production build in dist/
```
